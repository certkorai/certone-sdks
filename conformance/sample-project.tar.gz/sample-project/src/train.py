# Copyright (c) 2026 Certkor AI. All rights reserved.
"""Sample training entry point (fixture only — not executed by tests)."""

from __future__ import annotations

import pydicom  # noqa: F401  (fixture import, not installed)
import torch  # noqa: F401


def main() -> None:
    """Pretend to train a model."""
    print("training...")


if __name__ == "__main__":
    main()
